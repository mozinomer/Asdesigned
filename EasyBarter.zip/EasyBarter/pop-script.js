
// Upload File Code

$(document).ready(function(){
    $("#upload_link").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
    $("#upload_linko").on('click', function(e){
        e.preventDefault();
        $("#upload:hidden").trigger('click');
    });
});

// Hashtags
$(".hashtag").select2({
    maximumSelectionLength: 3
});

//Add friend
$(".add-friend").select2({
    maximumSelectionLength: 1
});

// Fourth Popup Select Friend
// function format(item, state) {
//     if (!item.id) {
//       return item.text;
//     }
//     var countryUrl = "https://lipis.github.io/flag-icon-css/flags/4x3/";
//     var url = countryUrl;
//     var img = $("<img>", {
//       class: "img-flag",
//       width: 26,
//       src: url + item.element.value.toLowerCase() + ".svg"
//     });
//     var span = $("<span>", {
//       text: " " + item.text
//     });
//     span.prepend(img);
//     return span;
// }
  
// $(document).ready(function() {
//     $("#countries").select2({
//         templateResult: function(item) {
//         return format(item, false);
//     }
// });  