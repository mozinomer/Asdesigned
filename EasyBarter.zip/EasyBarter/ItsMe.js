if ($(window).width() < 770) {
    $(".all-friends-box").click( function(e){
      e.preventDefault();
      $(".col-md-6.main-hr").addClass("active")
    })
    $(".single-message-top").click( function(e) {
      e.preventDefault();
       $(".col-md-6.main-hr").removeClass("active");
      $("body").removeClass("active")
    })

    $('.table').addClass('table-responsive');
    console.log("asd")
    $(".sliderMobileSlide").slick({
      infinite: false,
      slidesToShow: 1.2,
      slidesToScroll: 1,
      centerMode: false,
      arrows: false,
      dots: true
    });
    $(".sliderMobileSlides").slick({
      infinite: false,
      slidesToShow: 2,
      slidesToScroll: 1,
      centerMode: false,
      arrows: false,
      dots: true
    });
    $(".rightSideFooer h6").click( function(e) {
            $(".rightSideFooer h6").removeClass("active");
        $(".rightSideFooer ul").slideUp();
        if ($(this).hasClass("active")) {

        } else {
            $(this).parent().find("ul").slideDown();
            $(this).parent().find("ul").toggleClass("active");
            $(this).toggleClass("active");
        }
    });
    $(".hamburger").click( function(e) {
        e.preventDefault()
        $("nav.menuContainer").toggleClass("active");
    })
}
$(".headingForListDropDown").click( function(e) {
    $(this).parent().toggleClass("active");
})

// scroll Animation
jQuery(function($) {
  
  var doAnimations = function() {
    // Calc current offset and get all animatables
    var offset = $(window).scrollTop() + $(window).height(),
        $animatables = $('.boxContainerService.animatable, .listViews');
    // console.log($(window).height(), $(window).scrollTop());
    
    // Unbind scroll handler if we have no animatables
    if ($animatables.length == 0) {
      $(window).off('scroll', doAnimations);
    }
    
    // Check all animatables and animate them if necessary
    $animatables.each(function(i) {
       var $animatable = $(this);
      if (($animatable.offset().top + $animatable.height() - 20) < offset) {
        $animatable.removeClass('animatable').addClass('animated');
      }
    });
  };
  
  // Hook doAnimations on scroll, and trigger a scroll
  $(window).on('scroll', doAnimations);
  $(window).trigger('scroll');

});
$(".listView").click( function (e) {
  e.preventDefault();
  $(".services.GridView").addClass("deactivated");
  $(".ListView").addClass('active');
})
$(".GridView").click( function (e) {
  e.preventDefault();
  $(".services.GridView").removeClass("deactivated").addClass("active");
  $(".ListView").removeClass('active');
})

