$('.bannerHOmeContainer').slick({
	slidesToShow: 1,
	dots: false,
	arrows: false
})
$('.containerSLiderProduct').slick({
	slidesToShow: 4,
	dots: false,
	arrows: true
})
$('.sliderTestimonials').slick({
	slidesToShow: 1,
	dots: false,
	arrows: true
})