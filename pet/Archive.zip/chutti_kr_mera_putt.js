$('.bannerHOmeContainer').slick({
	slidesToShow: 1,
	dots: true,
	arrows: false
})
$('.containerSLiderProduct').slick({
	slidesToShow: 4,
	dots: false,
	arrows: true
})