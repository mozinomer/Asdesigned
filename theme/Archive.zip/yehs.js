$('.sliderCOntainerBanner').slick({
	slidesToShow: 1,
	dots: true,
	arrows: false,
})
$('.sliderCOntainerProductCOntainer').slick({
	slidesToShow: 6,
	dots: false,
	arrows: true,
})
$('.productSlider .sliderCOntainerProduct').slick({
	slidesToShow: 6,
	dots: false,
	arrows: true,
})
$('.newCollection .sliderCOntainerProduct').slick({
	slidesToShow: 4,
	dots: false,
	arrows: true,
})